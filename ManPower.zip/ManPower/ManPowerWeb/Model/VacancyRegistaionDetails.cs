﻿using System;

namespace ManPowerWeb.Model
{




    public class VacancyRegistaionDetails
    {
        public DateTime Date { get; set; }
        public string Address { get; set; }
        public string WebsiteLink { get; set; }
        public string BRN { get; set; }
        public string VacancyTOrJobP { get; set; }
        public string DropCPorHP { get; set; }
        public string SalaryLevel { get; set; }

        public string Level { get; set; }
        public string NumberOfVacan { get; set; }

        public string Name { get; set; }
        public string Position { get; set; }
        public string ContactNumber { get; set; }
        public string WhatsappNumber { get; set; }
        public string Email { get; set; }



    }
}
