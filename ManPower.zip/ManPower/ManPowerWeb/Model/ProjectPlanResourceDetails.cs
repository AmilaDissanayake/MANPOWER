﻿using System;

namespace ManPowerWeb.Model
{
    public class ProjectPlanResourceDetails
    {
        public string MName { get; set; }
        public string MWorkPlace { get; set; }
        public string MSubject { get; set; }

    }
}
