﻿using System;

namespace ManPowerWeb.Model
{
    public class ResourceProProgress
    {

        public DateTime Date { get; set; }
        public string NameOfTheProgram { get; set; }
        public string Institute { get; set; }
        public string Address { get; set; }
        public string SubjectAreaOrTopic { get; set; }
        public string NameOfTheOrganization { get; set; }
        public string OrganizationType { get; set; }

        public string Ds { get; set; }
        public string OrganizationAddress { get; set; }

        public string Name { get; set; }
        public string Position { get; set; }
        public string ContactNumber { get; set; }
        public string WhatsappNumber { get; set; }
        public string Email { get; set; }
        public string DetailsOfTheProvidedService { get; set; }



    }
}
